Terimakasih Semuanya
skrip ini jangan di jual ya, hargai kreator 

beli vps di atlantic-server.com aja awet aman terpercaya
