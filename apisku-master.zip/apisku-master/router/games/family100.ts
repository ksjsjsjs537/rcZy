import axios from "axios"

async function scrape() {
  try {
    const response = await axios.get(
      "https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json",
      {
        timeout: 30000,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
    )
    const src = response.data
    return src[Math.floor(Math.random() * src.length)]
  } catch (error: any) {
    console.error("API Error:", error.message)
    throw new Error("Failed to get response from API")
  }
}

export default [
  {
    metode: "GET",
    endpoint: "/api/games/family100",
    name: "family100",
    category: "Games",
    description: "This API endpoint provides a random question from the popular game 'Family 100' (also known as Family Feud). Each request delivers a new question along with its surveyed answers and their corresponding points. This endpoint is perfect for developing interactive quiz applications, entertainment platforms, or any scenario where a 'Family 100'-style game is desired. The response will be a JSON object containing the question and an array of answers with their scores.",
    tags: ["Games", "Family100", "Quiz", "Entertainment"],
    example: "",
    parameters: [],
    isPremium: false,
    isMaintenance: false,
    isPublic: true,
    async run({ req }) {
      try {
        const data = await scrape()

        if (!data) {
          return {
            status: false,
            error: "No result returned from API",
            code: 500,
          }
        }

        return {
          status: true,
          data: data,
          timestamp: new Date().toISOString(),
        }
      } catch (error: any) {
        return {
          status: false,
          error: error.message || "Internal Server Error",
          code: 500,
        }
      }
    },
  },
  {
    metode: "POST",
    endpoint: "/api/games/family100",
    name: "family100",
    category: "Games",
    description: "This API endpoint provides a random question from the popular game 'Family 100' (also known as Family Feud). Each request delivers a new question along with its surveyed answers and their corresponding points. This endpoint is perfect for developing interactive quiz applications, entertainment platforms, or any scenario where a 'Family 100'-style game is desired. The response will be a JSON object containing the question and an array of answers with their scores.",
    tags: ["Games", "Family100", "Quiz", "Entertainment"],
    example: "",
    requestBody: {},
    isPremium: false,
    isMaintenance: false,
    isPublic: true,
    async run({ req }) {
      try {
        const data = await scrape()

        if (!data) {
          return {
            status: false,
            error: "No result returned from API",
            code: 500,
          }
        }

        return {
          status: true,
          data: data,
          timestamp: new Date().toISOString(),
        }
      } catch (error: any) {
        return {
          status: false,
          error: error.message || "Internal Server Error",
          code: 500,
        }
      }
    },
  },
]